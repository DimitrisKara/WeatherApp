# Weather App

Simple Android app that uses the Accuweather API to find current weather conditions in a user-defined city.<br>

This project also contains methods that extract a JSONArray from an HTTP response.<br>

The Accuweather API can be found <a href="https://developer.accuweather.com/apis">here</a>.
